function showPopup() {
  var popupContainer = document.getElementById("popupContainer");
  popupContainer.style.display = "flex";
}

function closePopup() {
  var popupContainer = document.getElementById("popupContainer");
  popupContainer.style.display = "none";
}
